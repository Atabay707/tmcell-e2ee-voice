# TMCell E2EE Voice — başlangyç taslama

Bu taslama Altyn Asyr SIM-jaňynyň sesini şifrleýän taýýar programma däldir. Ol internetsiz şifrlenen ses programmasyny gurmak üçin başlangyç Flutter taslamasydyr.

## Häzirki ýagdaýy
- Flutter UI başlangyjy bar.
- AES-GCM bilen maglumat şifrlemek/açmak üçin demo kriptografiýa hyzmaty bar.
- Ses ýazmak, Bluetooth/Wi-Fi Direct arkaly maglumat geçirmek, X25519 açar alyş-çalşygy we Android/iOS rugsatlary entek birikdirilmedi.
- Şu görnüşde taslama diňe demo şifrleme üçin; hakyky şahsy gepleşik üçin ulanmaň.

## Möhüm tehniki çäklendirme
Adaty Altyn Asyr GSM/VoLTE jaňynyň ses akymyny üçünji tarap programmasy Android/iPhone-da alyp, onuň ýerine şifrlenen maglumat goýup bilmeýär. Munuň üçin operator derejesinde integrasiýa ýa-da ýörite enjam gerek. Internetsiz uzak aralyk üçin hem diňe telefon programmasy ýeterlik däl: operator tarapyndan maglumat geçirmek kanaly ýa-da başga infrastruktura gerek.

## Işletmek
1. Flutter SDK guruň: https://docs.flutter.dev/get-started/install
2. Terminalda şu bukja giriň.
3. `flutter create .` buýrugyny işlediň (Flutter platforma bukjalaryny döreder).
4. `flutter pub get`
5. `flutter run`

## Indiki ösüş tapgyrlary
1. Iki enjam üçin X25519 açar alyş-çalşygy we açarlary tassyklamak.
2. Audio capture/playback.
3. Ýakyn aralykda Bluetooth LE ýa-da Wi-Fi Direct transporty.
4. Android/iOS rugsatlary we fon işi.
5. Howpsuzlyk synagy; açar tassyklamasy we replay protection.
