import 'package:flutter_test/flutter_test.dart';
import 'package:tmcell_e2ee_voice/crypto_demo.dart';

void main() {
  test('AES-GCM demo encrypts and decrypts text', () async {
    final crypto = CryptoDemo();
    final key = await crypto.newDemoKey();
    const message = 'salam';
    final encrypted = await crypto.encryptText(message, key);
    final decrypted = await crypto.decryptText(encrypted, key);
    expect(decrypted, message);
  });
}
