import 'dart:convert';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';

/// AES-GCM demo utility.
/// IMPORTANT: This uses a randomly generated shared key only for a local demo.
/// It does not establish a secure key between two phones.
class CryptoDemo {
  final AesGcm _algorithm = AesGcm.with256bits();

  Future<SecretKey> newDemoKey() => _algorithm.newSecretKey();

  Future<SecretBox> encryptText(String text, SecretKey key) async {
    final nonce = _algorithm.newNonce();
    return _algorithm.encrypt(
      utf8.encode(text),
      secretKey: key,
      nonce: nonce,
      aad: Uint8List.fromList(utf8.encode('tmcell-e2ee-demo-v1')),
    );
  }

  Future<String> decryptText(SecretBox box, SecretKey key) async {
    final clearBytes = await _algorithm.decrypt(
      box,
      secretKey: key,
      aad: Uint8List.fromList(utf8.encode('tmcell-e2ee-demo-v1')),
    );
    return utf8.decode(clearBytes);
  }
}
