import 'package:flutter/material.dart';
import 'crypto_demo.dart';

void main() {
  runApp(const E2EEDemoApp());
}

class E2EEDemoApp extends StatelessWidget {
  const E2EEDemoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'E2EE Voice Starter',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B57)),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _status = 'Taslama taýýar. Ses we telefonara baglanyşyk entek ýok.';
  final _demo = CryptoDemo();

  Future<void> _runCryptoDemo() async {
    try {
      final key = await _demo.newDemoKey();
      const sample = 'Bu diňe synag habary — hakyky ses däl.';
      final encrypted = await _demo.encryptText(sample, key);
      final decrypted = await _demo.decryptText(encrypted, key);
      if (!mounted) return;
      setState(() {
        _status = 'Şifrleme synagy üstünlikli.\n'
            'Şifrlenen maglumat: ${encrypted.cipherText.length} baýt\n'
            'Açylan tekst: $decrypted';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _status = 'Synag şowsuz: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('E2EE Voice — başlangyç')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.lock_outline, size: 64),
          const SizedBox(height: 16),
          Text(
            'Şifrlenen gepleşik taslamasy',
            style: Theme.of(context).textTheme.headlineSmall,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          const Text(
            'Maksat: ses diňe iberijide şifrlenip, diňe kabul edijide açylýan '
            'ulgam döretmek. Bu başlangyç wersiýa adaty SIM-jaňy üýtgetmeýär '
            'we entek sesli jaň etmeýär.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Häzirki tapgyr', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('1. Kriptografiýa demo'),
                  const Text('2. Enjamara açar alyş-çalşygy — entek ýok'),
                  const Text('3. Ses we internetsiz transport — entek ýok'),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _runCryptoDemo,
                    icon: const Icon(Icons.verified_user_outlined),
                    label: const Text('Şifrleme synagyny işlet'),
                  ),
                  const SizedBox(height: 12),
                  SelectableText(_status),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Howpsuzlyk duýduryşy: bu prototip diňe görkezme üçin. '
            'Hakyky gizlin gepleşikler üçin ulanylmazdan öň açar alyş-çalşygy, '
            'şahsyýeti tassyklamak, ses transporty we garaşsyz howpsuzlyk barlagy gerek.',
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}
